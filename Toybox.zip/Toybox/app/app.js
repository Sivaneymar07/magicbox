var app=angular.module('myApp',['ngRoute']);
// var app=angular.module('myApp',['ngRoute']);
app.directive('backButton', function(){
    return {
      restrict: 'A',
      link: function(scope, element, attrs) {
        element.bind('click', goBack);
        function goBack() {
          history.back();
          scope.$apply();
        }
      }
    }
});  
// app.directive('aboutSection', function() {
//     return {
//         restrict: 'AE',
//         replace: true,

//         //templateUrl points to an external html template.
//         templateUrl: 'template/aboutTemp1.html'
//     };
// });
app.directive('aboutSection', function() {
   return {
       restrict: 'E',
       link: function(scope, element, attrs) {
           scope.getContentUrl = function() {
                return 'template/' + attrs.ver + '.html';
           }
       },
       template: '<div ng-include="getContentUrl()"></div>'
   }
});
app.directive('tempSection', function() {
   return {
       restrict: 'E',
       link: function(scope, element, attrs) {
           scope.getContentUrl = function() {
                return 'template/' + attrs.ver + '.html';
           }
       },
       template: '<div ng-include="getContentUrl()"></div>',
       controller: 'toyboxController',
       scope: { editorEnabled: '=', save: '&', plus: '&', disableEditor: '&'}
   }
});
// app.controller('toyboxController', function ($scope,$location,$anchorScroll) {
           
       
//         $scope.myvar=false;

//     $scope.menulist=['HOME','FIND TALENT','FIND A JOB'];
//         $scope.names=['Email','Tobias','Linus'];
//             //This will hide the DIV by default.
//               $scope.title="siva";
                          
//             $scope.save=function(){
//               console.log('save')
       
//         $scope.menulist.push($scope.title);

//         $scope.names.forEach(function(x, index){
//           if($scope.title === x) {
//             $scope.names.splice(index,1);
//           }
//         })
//         if($scope.title == 'Email') {
//           $scope.output1 = 'Email';
          
//         } else if ($scope.title == 'Tobias') {
//           $scope.output2 = 'Tobias';
//         } else if ($scope.title == 'Linus') {
//           $scope.output3 = 'Linus';
//         }

//       }
//       $scope.plus=function(){
//         console.log('ss')
//         $scope.myvar=true;
       
//       }
//       $scope.disableEditor=function(){
//         $scope.myvar=false;
//       }
//       $scope.scrollTo = function(scrollLocation){
//         var old = $location.hash();
//         $location.hash(scrollLocation);
//         $anchorScroll();
//         $location.hash(old);
//       } 
// });