app.controller('toyboxController', function ($scope,$location,$anchorScroll) {
           
        $scope.editorEnabled=false;

    $scope.menulist=['HOME','FIND TALENT','FIND A JOB'];
        $scope.names=['FAQ','CREATE OWN','HELP'];
            //This will hide the DIV by default.
          
                          
            $scope.save=function(){
        $scope.editorEnabled=true;
        $scope.menulist.push($scope.title);
        console.log($scope.menulist);
        $scope.names.forEach(function(x, index){
          if($scope.title === x) {
            $scope.names.splice(index,1);
          }
        })
        if($scope.title == 'Email') {
          $scope.output1 = 'Email';
          
        } else if ($scope.title == 'Tobias') {
          $scope.output2 = 'Tobias';
        } else if ($scope.title == 'Linus') {
          $scope.output3 = 'Linus';
        }

      }
      $scope.plus=function(){
        $scope.myvar=true;
        $scope.editorEnabled=false;
      }
      $scope.disableEditor=function(){
        $scope.myvar=false;
      }
      $scope.scrollTo = function(scrollLocation){
        var old = $location.hash();
        $location.hash(scrollLocation);
        $anchorScroll();
        $location.hash(old);
      } 
});