app.config(['$routeProvider',function($routeProvider) {

	$routeProvider
		.when('/',{
			templateUrl : 'partials/boxPage.html'
			
 		})
 		.when('/home',{
			templateUrl : 'partials/home.html'
			
 		})
		.when('/micro',{
			templateUrl : 'partials/microsite.html',
			controller : 'toyboxController'
			
 		})
 		.when('/temp',{
			templateUrl : 'template/micrositeTemp.html',
			controller : 'toyboxController'
			
 		})
		.when('/channel',{
			 templateUrl :'partials/chooseChannel.html'
		})

		.when('/bbox1',{
			templateUrl  :'partials/nature.html'
		})

		.when('/bbo1',{
			templateUrl  :'partials/designlayout.html'
		})
    
    	.when('/bOk',{
			templateUrl  :'partials/toybox.html'
		})
    	.when('/ready',{
			templateUrl  :'partials/readyPage.html'
			
		})
		.otherwise({
			redirectTo : '/',
			controller  : ''
		})
}]);