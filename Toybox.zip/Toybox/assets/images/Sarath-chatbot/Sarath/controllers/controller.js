var chatBot = angular.module('chatBot',['ngAnimate']);

chatBot.controller('chatBotCtrl', function($scope) {
	console.log("HELLO FROM THE OTHER SIDE");
	$scope.messages = {};
	var message_data = {
		greeting : "Hello Kevin.What can I do for you?",
		start : "Great !...",
		specifications : {
			header_width : "Choose a method",
			header_height : "Choose a design process to continue with.. ",
			body_width : "Great!What would be your preferred channel?",
			body_height : "What's the height of the body?",
			footer_width : "What's the width of the footer?",
			footer_height : "What's the height of the footer?"
		},
		toybox : ["Magicbox", "Toolbox", "Servicebox"],
		magicbox : ["ConceptBuilder","Designer","Testing","Factory"],
		ConceptBuilder : ["MobileApp","WebApp","Website","OmniChannel","AR","VR"]

	}
	var i = -1;
	
	$scope.func = function()
	{	
		i++
		$scope.messages[i]= "Kevin: "+$scope.sent_message;
		document.getElementById('chatmsg').value="";
		if($scope.sent_message=="Hi"|| $scope.sent_message=="hi"||$scope.sent_message=="Hello"||$scope.sent_message=="hello")
		{
			i++
			$scope.messages[i]=message_data.greeting;
		}
		else if($scope.sent_message=="ToyBox ConceptBuilder"||$scope.sent_message=="toybox" ||$scope.sent_message=="conceptbuilder")
		{
			i++
			$scope.messages[i]=message_data.start + message_data.specifications.header_width;
            i++
            $scope.messages[i]=message_data.toybox[0];
            i++
            $scope.messages[i]=message_data.toybox[1];
            i++
            $scope.messages[i]=message_data.toybox[2];
		}
		else if(i==7)
		{
			i++
			$scope.messages[i]=message_data.specifications.header_height;
			 i++
            $scope.messages[i]=message_data.magicbox[0];
            i++
            $scope.messages[i]=message_data.magicbox[1];
            i++
            $scope.messages[i]=message_data.magicbox[2];
            i++
            $scope.messages[i]=message_data.magicbox[3];
		}
		else if(i==13)
		{
			i++
		 	$scope.messages[i]=message_data.specifications.body_width;
			i++
            $scope.messages[i]=message_data.ConceptBuilder[0];
            i++
            $scope.messages[i]=message_data.ConceptBuilder[1];
            i++
            $scope.messages[i]=message_data.ConceptBuilder[2];
            i++
            $scope.messages[i]=message_data.ConceptBuilder[3];
            i++
            $scope.messages[i]=message_data.ConceptBuilder[4];
            i++
            $scope.messages[i]=message_data.ConceptBuilder[5];
		}
		// else if(i==9)
		// {
		// 	i++
		// 	$scope.messages[i]=message_data.specifications.body_height;
		// }
		// else if(i==11)
		// {
		// 	i++
		// 	$scope.messages[i]=message_data.specifications.footer_width;
		// }
		// else if(i==13)
		// {
		// 	i++
		// 	$scope.messages[i]=message_data.specifications.footer_height;
		// }
		// else
		// {
		// 	$scope.header_width = $scope.messages[5], $scope.header_height = $scope.messages[7], $scope.body_width = $scope.messages[9], $scope.body_height = $scope.messages[11]
		// 	$scope.footer_width= $scope.messages[13],$scope.footer_height= $scope.messages[15];
		// 	$scope.banner= true;
		// }
		// console.log($scope.messages)
	}
	$scope.func1= function(){
		$scope.chatbox=true;
		$scope.banner=false;
		console.log("Adadadasd")
	}

	$scope.optionFunction = function(message) {
		if(message =='Magicbox') {
			$scope.sent_message = message;
		} else if (message == 'Toolbox'){
			$scope.sent_message = message;
		} else if (message == 'Servicebox') {
			$scope.sent_message = message;
		} else if(message == 'ConceptBuilder'){
			$scope.sent_message = message;
		} else if(message == 'Designer'){
			$scope.sent_message = message;
		} else if(message == 'Testing'){
			$scope.sent_message = message;
		} else if(message == 'Factory'){
			$scope.sent_message = message;
		}else if(message == 'MobileApp'){
			$scope.sent_message = message;
		} else if(message == 'WebApp'){
			$scope.sent_message = message;
		} else if(message == 'Website'){
			$scope.sent_message = message;
		} else if(message == 'OmniChannel'){
			$scope.sent_message = message;
		} else if(message == 'AR'){
			$scope.sent_message = message;
		} else if(message == 'VR'){
			$scope.sent_message = message;
		} 

	}
	$scope.chatvisble = false;
	$scope.chaticon = function() {
		$scope.chatvisble = $scope.chatvisble ? true : false;
	}
});